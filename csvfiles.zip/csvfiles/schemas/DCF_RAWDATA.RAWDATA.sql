create or replace schema RAWDATA;

create or replace stream STREAM_POSTGRES_STAGE on directory(@POSTGRES_STAGE);